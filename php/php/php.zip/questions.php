<?php
require_once "gateway.php";
require_once "update.php";
require_once "sanitizer.php";
require_once "insert.php";
require_once "model.php";
require_once "load.php";
require_once "utility.php";
//require_once "mail.php";

$createUser = new InsertHandler($connect);

$sanitizeTxt = new Sanitizer(json_decode(file_get_contents('php://input'), true));
$inputData = $sanitizeTxt->cleanedText;
$loader = new loadInfo($db3,'');
if($inputData[$TYPE] == 'fetchAllCourses'){
     //here I have to fetch courses based on the user school and level(for k12) or department (UG)
     
     $sName = $inputData['sch'];
     $qLvl = $inputData['lvl'];
     $qDept = $inputData['dept'];
     /*
     $tb1="students";
 $tb2="guides";
 $tb3="transcriptInfo";
 $tb4="transcriptApk";
 $tb5="transactions";
  $tb6="transcriptReferral";
  $tb7="account";
  $tb8='admin';
  $tb9='materials';
  $tb10='questions';
  $tb11='belongsTo';
  $tb12='institution';
  $tb13='solution';
     */
     if($qLvl == ''){//requested for a university level course, Filter by Departments. qLevel ='UG' might be unneccessary
         $query = "SELECT  {$tb9}.verified, {$tb10}.qcode, {$tb10}.qtitle, {$tb10}.qtype, {$tb10}.year,{$tb10}.qID
         FROM 
         {$tb12} 
         INNER JOIN 
         {$tb11} ON {$tb12}.sID = {$tb11}.sID AND {$tb12}.sID = '{$sName}' 
         INNER JOIN 
         {$tb10} ON {$tb10}.qID = {$tb11}.qID AND {$tb10}.qlevel = 'UG' AND {$tb10}.department = '{$qDept}' 
         INNER JOIN 
         {$tb9} ON {$tb9}.materialID = {$tb10}.materialID ";
     }else{//department is not needed then so filter by k12 level: O or A
          $query = "SELECT  {$tb9}.verified, {$tb10}.qcode,  {$tb10}.qtitle, {$tb10}.qtype, {$tb10}.year,{$tb10}.qID
         FROM 
         {$tb12} 
         INNER JOIN 
         {$tb11} ON {$tb12}.sID = {$tb11}.sID AND {$tb12}.level = '{$qLvl}' 
         INNER JOIN 
         {$tb10} ON {$tb10}.qID = {$tb11}.qID AND {$tb10}.qlevel = '{$qLvl}'
         INNER JOIN 
         {$tb9} ON  {$tb9}.materialID = {$tb10}.materialID  ";
     }
     $courses = $loader->select($query);
     function checkAvailableSolution($matArray){
          global $loader,$tb13;
          $q="SELECT materialID FROM {$tb13} WHERE qID='{$matArray['qID']}' ";
          $val=$loader->select($q);
          if(is_null($val)){
               $matArray['solID']=null;
          }else{
               $matArray['solID']=$val[0]['materialID'];
          }
          return $matArray;
     }
     if(is_null($courses)){
          serverResponse(true,'No Questions Found');
     }else{
          serverResponse(true,array_map('checkAvailableSolution', $courses));
     }
    
     
     
    
}elseif($inputData[$TYPE] == 'viewCourse'){
     // first we check if a solution is available
     if($inputData['solID'] == 'null'){//no solution
          //get just questions filename
          $q="SELECT filename FROM {$tb9} INNER JOIN  {$tb10} ON {$tb9}.materialID = {$tb10}.materialID AND {$tb10}.qID = '{$inputData['qID']}'  ";
          $questionFileName=$loader->select($q);
          if(is_null($questionFileName)){
               serverResponse(false,'WRONG QUESTION ID');
          }else{
               //extract questions in image format
               $directory='../Question/';
               $link2file="http://localhost/uploads/";
               $images = pdftoimage2($link2file.$questionFileName[0]['filename'],extractfilename($questionFileName[0]['filename']),$directory);
               serverResponse(true,$images);
          }
          serverResponse(false, 'no solution');
     }else{
          serverResponse(false, 'came here');
     }

     
    
    
    
}if($inputData[$TYPE] == 'initialFetch'){// return popular courses
     serverResponse(true,'show popular courses');

}else{
     serverResponse(false,"Invalid Type sent");
}

?>