 <?php
session_start();
require_once "load.php";
require_once "insert.php";
require_once 'model.php';


if(isset($_GET['reference'])){
     function validate_input_text($text){
 	$trim_text=trim($text);
 	$sanitize_text=filter_var($trim_text,FILTER_SANITIZE_STRING);
 	return $sanitize_text;
 }
$payer= new InsertHandler($connect);
$loader= new loadInfo($db1,'');
    
	$query_str = $_SERVER['QUERY_STRING'];
		parse_str($query_str,$query_param);
		
		$stat=validate_input_text($query_param['status']);
		$ref=validate_input_text($query_param['reference']);
		$amt=validate_input_text($query_param['amount']);
		$appAmt=validate_input_text($query_param['app_amount']);
		
 	
 
   if(isset($_SESSION['UserID'])){
         $id=$_SESSION['UserID'];
   }else{
       $id=NULL;
   }//change to session id
   //$db1,"INSERT INTO transactions (UserID, Stat, Reference, Amount, Operator, date) VALUES (?,?,?,?,?,?) ",$stat,$ref,$amt,$operator,$id)
     $database = $db1;
    $table = $tb5;
    $qry = "INSERT INTO {$table} (studID,amount,hashCode,type,status,datetime) VALUES (?,?,?,?,?,?)";
     $type="sissss";
     $stud=NULL;
     $submitdate=date("Y-m-d H:i:s");
     $reqType = 'deposit';
      $param = [$stud,$appAmt,$ref,$reqType,$stat,$submitdate];
$loader = new loadInfo($db1,'');
$verifyHashCode = $loader->select("SELECT * FROM {$tb5} WHERE hashCode = '{$ref}'");
if(is_null($verifyHashCode)){
    $tID=$payer->registerUser($database,$qry,$type,$param);
  
}else{
    $t = $loader->select("SELECT transacID FROM {$tb5} WHERE hashCode = '{$ref}'");
    $tID=$t[0]['transacID'];

}
      
       if($stat == 'SUCCESSFUL'){
    header("Location: https://www.studentproguide.site/status?stat=true&transID={$tID}");
  
}else{
header("Location: https://www.studentproguide.site/status?stat=false&transID={$tID}");
}   

 

 //on transcript page check if a record exists to confirm
}

?>




