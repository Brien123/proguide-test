<?php
   
   function pdftoimage2($pdfLink,$name,$dir){
   
    if(is_dir($dir.$name)){
// directory exist. Just Fetch Files
if(is_array(scandir($dir.$name))){
return scandir($dir.$name);
exit();
}else{
echo "error fetching";
}


}else{
if(mkdir($dir.$name)){ //succesful creation of directory then add files
//pdf to image
$pdf=$dir.'ACC212.pdf';
$save=$dir.$name.'/converted-%03d.jpg';
$save1="output_file_name-%03d.png";
//exit(var_dump(exec('convert -density 150 "'.$pdfLink.'"  -quality 92 "'.$save.'"', $output, $return_var)));
if(!exec('convert -density 150 "'.$pdfLink.'"  -quality 92 "'.$save.'"', $output, $return_var)){
return $return_var.$pdfLink;//scandir($dir.$name);
}else{
echo "failed to Display";
} 
}
//-density 150 -antialias  name -resize 1024x -quality 100  -flatten -sharpen 0x1.0
}
}
function extractfilename($pdf){
$element=explode('/',$pdf); //break file link after every "/"
$filename=explode('.', $element[count($element) - 1]); // get the actual name of the file excluding its extension

return $filename[0];// returns the filename
}

function deleteDirectory($dirname){
if(is_dir($dirname)){
array_map("unlink", glob("$dirname/*"));
array_map("rmdir", glob("$dirname/*"));
rmdir($dirname);
}
}

?>