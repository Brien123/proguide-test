<?php
require_once 'vendor/autoload.php'; 
require_once 'gateway.php';
require_once 'sanitizer.php';
require_once 'model.php';
require_once 'load.php';
require_once 'insert.php';
require_once 'utility.php';


//$check = new Sanitizer(
//$inputData = json_decode(file_get_contents('php://input'), true);
function toPNG($link,$name,$dir){
    $pdf=$dir.'ACC212.pdf';
$save=$dir.$name.'/converted-%03d.jpg';
$save1="output_file_name-%03d.png";
//exit(var_dump(exec('convert -density 150 "'.$pdfLink.'"  -quality 92 "'.$save.'"', $output, $return_var)));
if(!exec('convert -density 150 "'.$pdfLink.'"  -quality 92 "'.$save.'"', $output, $return_var)){
return $return_var.$pdfLink;//scandir($dir.$name);
}else{
echo "failed to Display";
} 
}

echo phpinfo();

?>